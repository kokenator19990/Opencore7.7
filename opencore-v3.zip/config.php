<?php
// config.php
define('GEMINI_API_KEY', 'AIzaSyApQz8ccLK7aGu-FgODSDEyZT4G8ve9bIw');
?>
