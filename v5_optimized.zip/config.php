<?php
// config.php
define('GEMINI_API_KEY', 'AIzaSyCvxngXbJUPyWbUnepX31kjhwbwqvwfs-M');
?>
